//
//  VKAppApp.swift
//  Shared
//
//  Created by admin on 15.07.2022.
//

import SwiftUI

@main
struct VKAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
