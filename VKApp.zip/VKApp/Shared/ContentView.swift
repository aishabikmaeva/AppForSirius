//
//  ContentView.swift
//  Shared
//
//  Created by admin on 15.07.2022.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        Color.black
            .edgesIgnoringSafeArea(.all)
            .overlay(
                VStack(spacing: 0) {
                   
         
        
        Text("Cервисы VK").font(.title).foregroundColor(.white).padding(EdgeInsets(top: 5, leading: 0, bottom: 15, trailing: 0 ))
                
        
        VStack(alignment: .leading) {
    
        HStack {
            Image("vk")
            VStack(alignment: .leading) {
                Link("ВКонтакте", destination: URL(string: "https://vk.com/")!).foregroundColor(.white).font(.title)
                Text("Самая популярная соцсеть и первое суперприложение в России").foregroundColor(.white).font(.system(size: 13))
                
            }
        }
        HStack {
            Image( "mygames")
            VStack(alignment: .leading) {
                Link("My.Games", destination: URL(string: "https://my.games/")!).foregroundColor(.white).font(.title)
                Text("Игры для ПК, консолей и смартфонов, в которые играют сотни миллионов геймеров").foregroundColor(.white).font(.system(size: 13))
            }
        }
        HStack {
            Image( "sferum")
            VStack(alignment: .leading) {
                Link("Сферум", destination: URL(string: "https://sferum.ru/?p=start")!).foregroundColor(.white).font(.title)
                Text("Онлайн-платформа для обучения и образовательных коммуникаций").foregroundColor(.white).font(.system(size: 13))
            }
        }
        HStack {
            Image( "youla")
            VStack(alignment: .leading) {
                Link("Юла", destination: URL(string: "https://youla.ru/")!).foregroundColor(.white).font(.title)
                Text("Сервис объявлений на основе геолокации и интересов").foregroundColor(.white).font(.system(size: 13))
            }
        }
        HStack {
            Image( "samokat")
            VStack(alignment: .leading) {
                Link("Самокат", destination: URL(string: "https://samokat.ru/")!).foregroundColor(.white).font(.title)
                Text("Онлайн-ретейлер с доставкой товаров за 15 минут").foregroundColor(.white).font(.system(size: 13))
            }
        }
        
        HStack {
            Image( "citydrive")
            VStack(alignment: .leading) {
                Link("Ситидрайв", destination: URL(string: "https://citydrive.ru/")!).foregroundColor(.white).font(.title)
                Text("Каршеринг-сервис в крупнейших российских городах").foregroundColor(.white).font(.system(size: 13))
            }
        }
        
        HStack {
            Image( "cloud")
            VStack(alignment: .leading) {
                Link("Облако", destination: URL(string: "https://cloud.mail.ru/home/")!).foregroundColor(.white).font(.title)
                Text("Сервис для хранения файлов и совместной работы с ними").foregroundColor(.white).font(.system(size: 13))
            }
        }
        
        HStack {
            Image( "apteki")
            VStack(alignment: .leading) {
                Link("Все аптеки", destination: URL(string: "https://vseapteki.ru/")!).foregroundColor(.white).font(.title)
                Text("Онлайн-сервис для поиска и заказа лекарств по лучшей цене").foregroundColor(.white).font(.system(size: 13))
            }
        }
        HStack {
            Image( "calendar")
            VStack(alignment: .leading) {
                Link("Календарь", destination: URL(string: "https://calendar.mail.ru/")!).foregroundColor(.white).font(.title)
                Text("Планирование дня и эффективное управление временем").foregroundColor(.white).font(.system(size: 13))
            }
        }
        }
                    
                })
    }
}




 

